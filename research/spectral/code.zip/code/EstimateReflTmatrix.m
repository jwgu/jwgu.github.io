%Jun Jiang
%Last edited: 09/14/2012/
%Summary
%   The function is to recover the spectral reflectance under two commonly
%   available lighting conditions. Raw images need to be converted to pgm
%   before further processing. The image data then is saved in rawData.mat.
%   (when flatfielding is needed, the image data is saved as imgFlat.mat.)
%
%Publication:
%   Jun Jiang and Jinwei Gu. Recovering Spectral Reflectance under Commonly Available Lighting
%   Conditions. CVPR 2012 CCD
%
function []=EstimateReflTmatrix()
%% Load refl for characterization

w2=390:10:720;
ccRefl=ref('./data/passportCC09172011.txt');
refl=ccRefl(:,2:end-1)';
clear ccRefl;


%% Get eigenvectors of Munsell color chips (matte)
PCAonMunsellChips(6,w2);
load('evReflDB.mat');
w=w2;

% Get sigma
A=e;
B=refl;
sigma=A\B;

%% Set the picture folders. 
% CC is used for characterization and CCDC is used for validation

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fluorescent
folderD65='./data/cc_ccdc/overhead_cc/';
folderHandPickD65='./data/cc_ccdc/overhead_ccdc/';

% tungsten
folderIllA='./data/cc_ccdc/lamp_cc/';
folderHandPickIllA='./data/cc_ccdc/lamp_ccdc/';
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


disp(folderD65);
disp(folderHandPickD65);
disp(folderIllA);
disp(folderHandPickIllA);


%% Get radiance for characterization (CC)

[radiance1]=GetRGBdc(folderD65,4,6,8,'xyCorner.mat');
[radiance2]=GetRGBdc(folderIllA,4,6,8,'xyCorner.mat');

radiance1=radiance1./(2^16);
radiance2=radiance2./(2^16);

radiance=[radiance1;radiance2];


clear ans;
clear fid;

%% Get matrix T (radiance difference)
A=sigma;
b=radiance;
T=b*pinv(A);




%% Get matrix T (reflectance difference)
T=inv(pinv(e)*refl*pinv(radiance))


%% Get matrix T (color difference)
optTDeltaE=1;
if(optTDeltaE)
    start=T;
    %options = optimset('Display','iter');
    options=[];
    %to minimize deltaE under D65 and illA
    [optT]= fminsearch('TmatrixDeltaE',start,options,refl,radiance,e,w);
    
    T=optT
    
    
end

%% Get radiance for validation (CCDC)

[radiancePick1]=GetRGBdc(folderHandPickD65,12,20,4,'xyCorner.mat');
[radiancePick2]=GetRGBdc(folderHandPickIllA,12,20,4,'xyCorner.mat');

radiancePick1=radiancePick1./(2^16);
radiancePick2=radiancePick2./(2^16);

radiancePick=[radiancePick1;radiancePick2];


%% Load CCDC reflectance (ground truth)
ccdcRefl=load('CCDC_meas.mat');
ccdcRefl=ccdcRefl.CCDC_meas;
ccdcRefl=ccdcRefl.spectra;

testPatches=ccdcRefl(2:end-1,:);



%% Recovery of CCDC reflectance by base line (w/o any constaints)
b=radiancePick;
sigmaPick=inv(T)*b;

XhandPick=e*sigmaPick;


[rmsBase,colorDiffBase,colorDiffABase,rmsBaseNormalized]= ValidateCCDC(XhandPick,testPatches,w);
    


%% Recovery of CCDC reflectance by least square method (w/ the smoothness constraint)

b=radiancePick;
lambda=0.001

for i=1:size(b,2)
    [sigmaPickSmooth(:,i),AAA,bbb]=RecoverSigmaBV(T,b(:,i),lambda,e,w);
end



XhandPickSmooth=e*sigmaPickSmooth;

[rmsSmooth,colorDiffSmooth,colorDiffASmooth]= ValidateCCDC(XhandPickSmooth,testPatches,w);
        
%% Recovery of CCDC reflectance by Gaussian mixture model
gmm=1;
if(gmm)
    [sigmaOpt]=gmmReflMain(sigmaPick,e,T,b,w);
    
    XhandPickGMM=e*sigmaOpt;
    
        

    [rmsGMM,colorDiffGMM,colorDiffAGMM]= ValidateCCDC(XhandPickGMM,testPatches,w);
    
end


%% Best theoretical prediction
sigmaBest=e\testPatches;

reflBestHat=e*sigmaBest;

[rmsBest,colorDiffBest,colorDiffABest]= ValidateCCDC(reflBestHat,testPatches,w);


%% Performance evaluation by displaying the statistics (specrtral RMS, deltaE D65, and deltaE A)
statBase=[mean(rmsBase),mean(colorDiffBase),mean(colorDiffABase)]
statSmooth=[mean(rmsSmooth),mean(colorDiffSmooth),mean(colorDiffASmooth)]
statGMM=[mean(rmsGMM),mean(colorDiffGMM),mean(colorDiffAGMM)]

statBest=[mean(rmsBest),mean(colorDiffBest),mean(colorDiffABest)]


end
