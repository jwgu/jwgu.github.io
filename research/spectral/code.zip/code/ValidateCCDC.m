function [rms,colorDiff,colorDiffA,rmsNormalized]=ValidateCCDC(XhandPick,testPatches,w)
%% remove undesired or replicated patches
glossyP=[79,99,119,139,159,179,199,219];
bwP=21:20:201;
bwP2=bwP+19;
unwantedP4Val=[glossyP,bwP,bwP2];


%remove unwanted patches (duplicate ones)
if(size(XhandPick,2)==240)
    XhandPick=GetCCDC(unwantedP4Val,w,XhandPick);
end

if(size(testPatches,2)==240)
    testPatches=GetCCDC(unwantedP4Val,w,testPatches);
end

[rms,colorDiff,colorDiffA,rmsNormalized]=EvaluatePerformance(XhandPick,testPatches,w);



end
