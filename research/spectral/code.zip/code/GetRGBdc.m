%Jun Jiang
%09/14/2012
%Summary
%   The function is to get the RGB digital counts from images
%
%[IN]
%   folder: the folder under which image data is stored
%   nRow: the number of rows 
%   nCol: the number of columns
%   patchSamplingSz: the size of the window within which the pixel values
%   are averaged
%   xyCornerFile: the four corners of the areas of interest
%
%[OUT]
%   radiance: the radiance value of the selected areas
%
function [radiance]=GetRGBdc(folder,nRow,nCol,patchSamplingSz,xyCornerFile)

if(nargin==0)
    disp('folder has to be specified');
    return;
end

load([folder,'rawData.mat']);



%%
img=double(img);

%for Canon 60D

% bk=imread('./data/ccp_ccdc/canon60D_black.pgm');
% imgDark=double(bk);

imgDark=1025;

img2=img-double(imgDark);
img2(img2<0)=0;

%%
%Bayer pattern of Canon 60D is RGGB
imgR = img2(1:2:end-1, 1:2:end);

imgG = img2(1:2:end-1, 2:2:end);

imgB = img2(2:2:end, 2:2:end);
    

%%

if(~isempty(dir([folder,'imgFlat.mat'])))
  
    load([folder,'imgFlat.mat']);
    
    DoFlatFielding=1;
    imgFlat=double(imgFlat)-double(imgDark);
    
    imgFlat(imgFlat<0)=0;
    
    imgFlatR = imgFlat(1:2:end-1, 1:2:end);

    imgFlatG = imgFlat(1:2:end-1, 2:2:end);

    imgFlatB = imgFlat(2:2:end, 2:2:end);


else
    DoFlatFielding=0;
    
end

%%
%xyCornerFile='xyCorner.mat';
if(isempty(dir([folder,xyCornerFile])))
    imagesc(imgG);
    grid on;
    
    xyCorner=ginput(4);
    save ([folder,xyCornerFile], 'xyCorner');
else
    load([folder,xyCornerFile]);
end



%%
xyCorner=round(xyCorner);
xyCorner=flipdim(xyCorner,2);

rowRange=min(xyCorner(1:2,1)):min(xyCorner(3:4,1));
colRange=min(xyCorner([1,4],2)):max(xyCorner([2,3],2));

imgR=imgR(rowRange,colRange);
imgG=imgG(rowRange,colRange);
imgB=imgB(rowRange,colRange);

figure;
imagesc(imgR);
title(['imgR before flatfielding (',folder,')']);
%%
if(DoFlatFielding)
    imgFlatR=imgFlatR(rowRange,colRange);
    imgFlatG=imgFlatG(rowRange,colRange);
    imgFlatB=imgFlatB(rowRange,colRange);
    
    
    imgFlatR=imgFlatR./mean(imgFlatR(:));
    imgFlatG=imgFlatG./mean(imgFlatG(:));
    imgFlatB=imgFlatB./mean(imgFlatB(:));
    
    
    imgR=imgR./imgFlatR;
    imgG=imgG./imgFlatG;
    imgB=imgB./imgFlatB;
    
    figure;
    imagesc(imgFlatR);
    colorbar;
    title(['white flat field (R) (',folder,')']);
    
    figure;
    imagesc(imgR);
    title(['imgR after flatfielding (',folder,')']);
    
end

%%
clear img;
clear img2;
clear imgDark;
clear imgFlat;
clear Y;
clear imgFlatR;
clear imgFlatG;
clear imgFlatB;

%%
figure;imagesc(imgR);grid on;


load([folder,'fileParameter.txt'])
%format of fileParameter.txt
% 1st row: startImgNo             endImgNo
% 2nd row: startFlatFieldingNo    endFlatFieldingNo



patchSz=[size(imgR,1)/nRow,size(imgR,2)/nCol];

col=patchSz/2:patchSz:size(imgG,2);
row=patchSz/2:patchSz:size(imgG,1);



col=round(col);
row=round(row);

hold on; plot(col,repmat(row,length(col),1),'ko')



%%
radiance=zeros(3,nRow*nCol);

[radiance(1,:)]=GetPatchRadiance(imgR,row,col,patchSamplingSz);
[radiance(2,:)]=GetPatchRadiance(imgG,row,col,patchSamplingSz);
[radiance(3,:)]=GetPatchRadiance(imgB,row,col,patchSamplingSz);







end