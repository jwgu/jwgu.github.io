%Jun Jiang
%09/14/2012
%Summary
%   This is the objective function to calculate matrix T by minimizing color difference 
%
%[IN]
%   T: The T matrix
%   refl: the spectral reflectance
%   radiance: the radiance meaured by camera
%   e: the eigenvector of reflectance
%   w: the wavelength range
%
%[OUT]
%   weightedDeltaE: the color difference metric
%   colorDiffD65: the color difference under CIE D65
%   colorDiffA: the color difference under CIE IllA
%   rms: the spectral rms error
%
function [weightedDeltaE,colorDiffD65,colorDiffA,rms]=TmatrixDeltaE(T,refl,radiance,e,w)

sigma=pinv(T)*radiance;

reflHat=e*sigma;

[rms,colorDiffD65,colorDiffA]=EvaluatePerformance(reflHat,refl,w);

rms=mean(rms);
colorDiffD65=mean(colorDiffD65);
colorDiffA=mean(colorDiffA);

weightedDeltaE=colorDiffD65+colorDiffA;

end
