%Jun Jiang
%05/15/2011
%Summary
%   The function is the objective function for nonlinear optimization
%[IN]
%   sigma: starting value of sigma
%   e: eigenvector (sigma*e=refl)
%   T: T matrix (sigma*T=I)
%   I: intensity (R,G, or B raw data)
%   lambda: a constant for weighting
%   gmmModel: the gaussian mixture model struct
%[OUT]
%   g: the minimzed function value
%
%
function [g]=gmmRecoverSigma(sigma,T,I,lambda,gmmModel)

%fminunc
g1=norm(T*sigma-I);


numGmm=size(gmmModel.mu,2);

p=zeros(1,numGmm);
for i=1:numGmm
    p(i)=gmmModel.weight(i)*mvnpdf(sigma',gmmModel.mu(:,i)',gmmModel.Sigma(:,:,i));
end

if(sum(p)==0)
%    disp('sum of p is equal to zero');
    g2=0;
else
    g2=log(sum(p));
end

g=lambda*g1-g2;

end
