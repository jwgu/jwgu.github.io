%Jun Jiang
%09/14/2012
%Summary
%   The function is to get the patch radiance
%
%[IN]
%   img: the image data
%   row: the row indexes
%   col: the column indexes
%   sampleSz: the window size within which the pixel values are averaged
%
%[OUT]
%   radiance: the radiance value of the selected areas
%
function [radiance]=GetPatchRadiance(img,row,col,sampleSz)

if(mod(sampleSz,2))
    sampleSz=sampleSz+1;
end


%save in row major order
radiance=zeros(1,length(row)*length(col));

for i=1:length(row)
    for j=1:length(col)
        pixels=img(row(i)-sampleSz/2:row(i)+sampleSz/2,col(j)-sampleSz/2:col(j)+sampleSz/2);
%        radiance(i,j)=mean(pixels(:));
        radiance((i-1)*length(col)+j)=mean(pixels(:));
    end
end



end
