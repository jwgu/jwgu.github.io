%Jun Jiang
%09/14/2012
%Summary
%   The function is to get the LAB value given reflectance, illuminant,
%   and color matching function
%   
%[IN]
%   refl: the spectral reflectance
%   ill: the illuminant spectrum
%   cmf: the color matching function 
%   w: the wavelength range
%
%[OUT]
%   LAB: the LAB value
%
function [LAB]=GetLAB(refl,ill,cmf,w)

WXYZ=ref2XYZNoLoop(ones(length(w),1),cmf,ill);
XYZ=ref2XYZNoLoop(refl,cmf,ill);
LAB=XYZ2LabVer4(XYZ,WXYZ);

end
