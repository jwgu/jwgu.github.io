%Jun Jiang
%05/02/2010
%Summary
%   The function is to recover reflectance based on the illuminant (2
%   spectra), the camera response function, measured digital counts (under
%   2 known light sources) and the basis vectors.
%
%[IN]
%   T: T matrix
%   radiance: rgb values 3-by-2 (1 RGB triplet under each light source)
%   lambda: smoothness weight
%   e: eigenvectors (basis vector)
%   w: wavelength
%
%[OUT]
%   X: scalar (1-by-k, k is the number of eigenvectors retained)
%
function [X,AAA,bbb]=RecoverSigmaBV(T,radiance,lambda,e,w)


numE=size(e,2);

%%
% A is composed of the matrix corresponding to camera signals
A=T;
b=radiance;

% disp('weighting on I=sigma*T');
% b2=[b(1:3)./sum(b(1:3));  b(4:6)./sum(b(4:6))];
%
% for i=1:size(A,1)
%     A(i,:)=A(i,:).*b2(i)./b(i);
% end
%
% b=b2;

%% second derivative used for smoothness

AA=zeros(length(w)-2,numE);
for i=1:size(AA,1)
    AA(i,:)=[-1,2,-1]*e(i:i+2,:).*lambda;
end

%2
% AA=zeros(length(w),numE);
% for i=1:size(AA,1)
%     if(i==1)
%         AA(1,:)=[1,-2,1]*e(1:3,:).*lambda;
%     elseif(i==size(AA,1))
%        AA(i,:)=[1,-2,1]*e(end-2:end,:).*lambda;
%     elseif(i==2)
%         AA(2,:)=[-2,5,-4,1]*e(1:4,:).*lambda;
%     elseif(i==size(AA,1)-1)
%         AA(i,:)=[-2,5,-4,1]*e(end-3:end,:).*lambda;
%     else
%         AA(i,:)=[1,-4,6,-4,1]*e(i-2:i+2,:).*lambda;
%     end
%
%
% end


bb=zeros(size(AA,1),1);

%%

AAA=[A;AA];
bbb=[b;bb];


X=pinv(AAA)*bbb;

if(1)
    %
    start = X;
    
    %Constraint
    
    lb = [];
    ub = [];
    
    %X multiplied by e is the reflectance, and therefore the product should be
    %between 0 and 1.
    Aneq=[e;-e];
    bneq=[ones(length(w),1);zeros(length(w),1)];
    
    options = optimset('LargeScale','off','Display','iter');
    X=lsqlin([A;AA],[b;bb],Aneq,bneq,[],[],lb,ub,start,options);
end

end
