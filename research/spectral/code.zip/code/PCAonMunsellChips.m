%Jun Jiang
%09/14/2012

%Summary
%   the function is to do PCA on a spectral database, Munsell color, e.g.
%[IN]
%   retainEV: the number of eigenvectors to retain
%   w2: wavelength range 
%
%[OUT]
%   reflDB: reflectance database
%   e: eigenvectors
%
function [reflDB,e]=PCAonMunsellChips(retainEV,w2)
%% Do PCA on Munsell chips

load('./data/munsell380_800_1.mat');

w=380:1:800;


munsell=interp1(w,munsell,w2);

if(nargin<3)
    addNaturalRefl=0;
end


reflDB=munsell;
    


%more than 6 eigenvectors do not help.
[e,v]=GetEigenvector(reflDB,retainEV);
save ('evReflDB.mat', 'e','w','reflDB');



function [e,v]=GetEigenvector(refl,retainE)
A=refl*refl';

if(nargin==1)
    retainE=6;
end

[e,v] = eig(A);

v=diag(v);

v=v(end-retainE+1:end);
e=e(:,end-retainE+1:end);

v=flipdim(v,1);
e=flipdim(e,2);

