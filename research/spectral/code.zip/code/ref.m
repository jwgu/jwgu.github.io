%Jun Jiang
%6/25/2010
%Summary
%   The function is to extract and plot the reflectance curves from the
%   file specified as input
%[IN]
%   filename: string, e.g. 'c01n.txt', 'd01n.txt'
%[OUT]
%   reflectance: reflectance data in the file
%
function [reflectance]=ref(filename, makePlot)
fid=fopen(filename);
c=textscan(fid,'%d %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f'...
    ,'headerlines',15);
c=cell2mat(c(3:end));

reflectance=c;

fclose(fid);

if(nargin==2 && makePlot==1)
    plot(380:10:730,c);
    xlabel('Wavelength (nm)');
    ylabel('Reflectance factor(R)');
    axis([380,730,0,1]);
    title(filename);
end

end