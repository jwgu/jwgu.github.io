%05/15/2011
%Chris
%Summary
%   The function is to nonlinearly optimize the sigma (simga*basis vector
%   is reflectance) by gaussian mixture model
%[IN]
%   sigma: starting value of sigma
%   e: eigenvector (sigma*e=refl)
%   T: T matrix (sigma*T=I)
%   I: intensity (R,G, or B raw data)
%
%[OUT]
%   sigmaOpt: optimized sigma
%
function [sigmaOpt]=gmmReflMain(sigma,e,T,I,w)

lambda=20000;

% load('munsell380_800_1.mat');
% w2=380:1:800;
% %w=390:10:720;
%   
% munsell2=interp1(w2,munsell,w);
% 
load('evReflDB.mat');


sigmaOpt=zeros(size(sigma));
option=optimset('Algorithm','levenberg-marquardt');
 
% for i=1:size(sigma,2)
%     [sigmaOpt(:,i)]=fminunc(@gmmRecoverRefl,zeros(size(sigma,1),1),option,e2,T,I(:,i),lambda,gmmModel);
% end


%% Get sigma
A=e;
B=reflDB;
sigmaMunsell=A\B;


[label,gmmModel]=emgm(sigmaMunsell,3);

%spread(sigmaMunsell(1:2,:),label);


for i=1:size(sigma,2)
    [sigmaOpt(:,i)]=fminunc(@gmmRecoverSigma,zeros(size(sigma,1),1),option,T,I(:,i),lambda,gmmModel);
end



%%



end
