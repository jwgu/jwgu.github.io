%Jun Jiang
%Last edited: 09/14/2012/
%Summary
%   The function is to pre-process the captured images
% 1. convert from image raw to pgm
% 2. average the images if needed
% 3. save in mat file
% 4. Do the same thing for flat fielding images if needed
%
%Publication:
%   Jun Jiang and Jinwei Gu. Recovering Spectral Reflectance under Commonly Available Lighting
%   Conditions. CVPR 2012 CCD

function []=AveImg()
% Load info of captured images
folder='./data/cc_ccdc/lamp_cc/';

extension='.CR2';

load([folder,'fileParameter.txt']);

startImgNo=fileParameter(1,1);
endImgNo=fileParameter(1,2);

startFFNo=fileParameter(2,1);
endFFNo=fileParameter(2,2);

%% Convert from CR2 to pgm 

for i=startImgNo:endImgNo
    if(i>=1000)
        filename=[folder,'IMG_'];
    elseif(i>=100)
        filename=[folder,'IMG_0'];
    elseif(i>=10)
        filename=[folder,'IMG_00'];
    else
        filename=[folder,'IMG_000'];

    end
    
        system(['./dcraw -4 -D -j -v -t 0 ', [filename,num2str(i),extension]]);
end

%flat fielding files
for i=startFFNo:endFFNo
    if(i>=1000)
        filename=[folder,'IMG_'];
    elseif(i>=100)
        filename=[folder,'IMG_0'];
    elseif(i>=10)
        filename=[folder,'IMG_00'];
    else
        filename=[folder,'IMG_000'];

    end
    
    system(['./dcraw -4 -D -j -v -t 0 ', [filename,num2str(i),extension]]);
end



%% Average img data
extension='.pgm';

for i=startImgNo:endImgNo
    
    if(i>=1000)
        filename=[folder,'IMG_'];
    elseif(i>=100)
        filename=[folder,'IMG_0'];
    elseif(i>=10)
        filename=[folder,'IMG_00'];
     else
        filename=[folder,'IMG_000'];
    end
    
    imgFile=[filename,num2str(i),extension];
    
    if(~isempty(dir(imgFile)))
        imgBuf = imread(imgFile);
        imgBuf=double(imgBuf)./(endImgNo-startImgNo+1);
        if(i==startImgNo)
            img=imgBuf;
        else
            img=img+imgBuf;
        end
    end
    
    
    
end

img=uint16(img);
save ([folder,'rawData.mat'], 'img');





%% Average flat-fielding images
if(startFFNo~=0)
    
    for i=startFFNo:endFFNo
    
    if(i>=1000)
        filename=[folder,'IMG_'];
    elseif(i>=100)
        filename=[folder,'IMG_0'];
    elseif(i>=10)
        filename=[folder,'IMG_00'];
     else
        filename=[folder,'IMG_000'];
    end
    
        imgBuf = imread([filename,num2str(i),extension]);
        imgBuf=double(imgBuf)./(endFFNo-startFFNo+1);
        if(i==startFFNo)
            imgFlat=imgBuf;
        else
            imgFlat=imgFlat+imgBuf;
        end
        
    end
    
    imgFlat=uint16(imgFlat);
    
    save ([folder,'imgFlat.mat'], 'imgFlat');
    
    
end



