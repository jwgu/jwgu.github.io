%Jun Jiang
%09/17/2008
%Homework 3 Question 4
%Summary:
%   This program takes a matrix of reflectance factor data, a set of CIE color matching functions
%   and the spectral power distribution of a light source then returns a 3-by-n
%   (n is the number of reflectance samples) of CIE tristimulus values XYZ.
%   See page 56 of 'Principle of Color Technology' for reference.
%
%Solution:
%   XYZ=[IlluminantM]*[ObserverM]*[ReflectanceM];
%
%   Assuming deltaLamda is 10
%   k=100/(Observer(:,2)'*Illuminant*deltaLamda);
%
%   X=k*((Observer(:,1))')*diag(Illuminant)*ReflectanceFactorM(:,i)*deltaLamda;
%   Y=k*((Observer(:,2))')*diag(Illuminant)*ReflectanceFactorM(:,i)*deltaLamda;
%   Z=k*((Observer(:,3))')*diag(Illuminant)*ReflectanceFactorM(:,i)*deltaLamda;
%
%function [XYZM]= ref2XYZ(ReflectanceFactorM, Observer, Illuminant)
%[IN]:
%   ReflectanceFactorM: a n-by-1 matrix of reflectance factor data
%   Observer: a n-by-3 matrix of CIE color matching functions
%   Illuminant: a n-by-1 matrix representing spectral power distribution of a light source
%   k: to get absolute XYZ (like for illuminant), k can be set as 683.
%                   By default, it is set to be 10nm
%[OUT]:
%   XYZM: a 3-by-n matrix
%   (n is the number of reflectance samples) of CIE tristimulus values XYZ.

function [XYZM]= ref2XYZNoLoop(ReflectanceFactorM, Observer, Illuminant,k)

%deltaLamda can be either 10 or 20
deltaLamda=10;

%illuminant normalization constant
if(nargin==3)
    
    
    k=100./(Observer(:,2)'*Illuminant*deltaLamda);
        
end



%Calculating Tristimulus
X=k*((Observer(:,1))')*diag(Illuminant)*ReflectanceFactorM*deltaLamda;
Y=k*((Observer(:,2))')*diag(Illuminant)*ReflectanceFactorM*deltaLamda;
Z=k*((Observer(:,3))')*diag(Illuminant)*ReflectanceFactorM*deltaLamda;

%cat matrix
XYZM=[X;Y;Z];




end
