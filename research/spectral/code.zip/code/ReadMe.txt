The folder contains code to recover the spectral reflectance under commonly available lighting conditions. An example is given here.

1. EstimateReflTmatrix is the main entry to run the code

2. Before running EstimateReflTmatrix.m, image raw has to be converted to pgm and then saved in mat file by AveImg.m

3. The example images are contained in ./data/cc_ccdc

4. If you have any questions, feel free to contact me by email: jxj1770@rit.edu

Jun Jiang
09/14/2012
