%Jun Jiang
%09/14/2012
%Summary
%   The function is to evaluate the recovery reflectance
%
%[IN]
%   X: The recovered reflectance
%   refl: the ground truth
%   w: the wavelength range
%
%[OUT]
%   rms: the spectral rms
%   colorDiff: the color difference under CIE D65
%   colorDiffA: the color difference under CIE IllA
%   rmsNormalized: the spectral rms normalized (w/ the denominator of the
%   reflectance itself)
%
function [rms,colorDiff,colorDiffA,rmsNormalized]=EvaluatePerformance(X,refl,w)
%% Evaluate spectral error
rms=X-refl;
rms=rms.*rms;
rms=mean(rms);
%disp('RMS of spetral error (overall)');
rms=sqrt(rms);

rmsNormalized=rms./(sqrt(mean(refl.*refl)));

%% Evaluate color difference (illD65 & cie.cmf2deg)
cie=getCieStruct2(w);

LabTarget=GetLAB(refl,cie.illD65,cie.cmf2deg,cie.lambda);
LabHat=GetLAB(X,cie.illD65,cie.cmf2deg,cie.lambda);

% LabTarget=GetLAB(refl,cie.illD65,cmf,cie.lambda);
% LabHat=GetLAB(X,cie.illD65,cmf,cie.lambda);

%disp('col diff under D65');
colorDiff=deltaE00(LabTarget,LabHat);
mean(colorDiff);


% Evaluate color difference (illA & cie.cmf2deg)
LabTarget=GetLAB(refl,cie.illA,cie.cmf2deg,cie.lambda);
LabHat=GetLAB(X,cie.illA,cie.cmf2deg,cie.lambda);

% LabTarget=GetLAB(refl,cie.illA,cmf,cie.lambda);
% LabHat=GetLAB(X,cie.illA,cmf,cie.lambda);

%disp('col diff under illA');
colorDiffA=deltaE00(LabTarget,LabHat);
mean(colorDiffA);


%disp('Reminder: part of the colormetric error might also result from the discrapancy between camera response functions and human color matching functions');




end


