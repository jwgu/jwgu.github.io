%Jun Jiang
%09/24/2008
%Summary:
%   This function takes XYZ of white point and 3-n matrix of XYZ values,
%converting XYZ to LAB value.
%   The function uses neither loop nor "find" function to achieve the conversion of multiple XYZ tuples.
%Instead, it uses logical indexing to realize the function of f(x)
%
%[IN] 3-n Matrix of XYZ values, and XYZ of white point
%[OUT] 3-n Matrix of LAB

function LabM=XYZ2LabVer4(XYZM,WXYZ)

ratio=diag(1./WXYZ)*XYZM;

XYZratio=f4(ratio);

LStar=116.*XYZratio(2,:)-16;
 
aStar=500*(XYZratio(1,:)-XYZratio(2,:));

bStar=200*(XYZratio(2,:)-XYZratio(3,:));
   
LabM=cat(1,LStar,aStar,bStar);

end
