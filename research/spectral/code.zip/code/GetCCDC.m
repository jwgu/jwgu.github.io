%Jun Jiang
%09/14/2012
%Summary
%   The function is to get the reflectance of CCDC 
%
%[IN]
%   unwantedP: the index of unwanted patches in CCDC. Some patches are
%   duplicated or glossy thus being excluded from validation
%   w2: the wavelength range
%   reflectance: the spectral reflectance of 240 patches in CCDC
%
%[OUT]
%   refl: the spectral reflectance of CCDC (w/o the unwanted patches)
%
function [refl]=GetCCDC(unwantedP,w2,reflectance)

if(nargin<3)
    reflectance=load('CCDC_meas.mat');
    reflectance=reflectance.CCDC_meas;
    reflectance=reflectance.spectra;

    w=380:10:730;

end


numRefl=size(reflectance,2);

refl=zeros(length(w2),numRefl);

if(nargin<3)
    for i=1:numRefl
        refl(:,i)=interp1(w(find(w==w2(1)):find(w==w2(end))),reflectance(find(w==w2(1)):find(w==w2(end)),i),w2);
    end

else
    refl=reflectance;
end


w=w2;

range=21:220;

refl2=zeros(length(w),length(range)-length(unwantedP));

idx=1;
for i=range(1):range(end)
    if(isempty(find(unwantedP==i)))
        refl2(:,idx)=refl(:,i);
        idx=idx+1;
    end
    
end


clear refl;
refl=refl2;



end
