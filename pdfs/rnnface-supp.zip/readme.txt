This supplementary material has two parts. 

The first part is a pdf file, supp.pdf, that has more plots of the
results of facial landmark estimation on 300-VW dataset.

The second part is the pptx file, supp.pptx, that has videos
demonstrating the results of head pose and facial landmark estimation,
as well as an example sequence of the SynHead dataset. 

The three video files embedded in the pptx are also provided as separate
mp4 files. They use H.264 codec. They have no audio. 

Thank you.


