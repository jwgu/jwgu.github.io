Paper ID: 6

The supplement material include the stitched videos for several figures
in the paper. These videos are encoded with standard H264 codec with
ffmpeg. Due to size limit, these videos are resized to 1/4 of full size
in both x and y directions. There is no audio in these videos.

Each sub folder includes the stitched videos for several different
methods. 

autostitch_per_frame.avi        OpenCV AutoStitch Per Frame

autostitch_fix_seam.avi         OpenCV AutoStitch Fix Seam

cpw_per_frame.avi               CPW Per Frame

videostitch_v2.avi              Commerical software VideoStitch V2

stcpw.avi                       The proposed STCPW method

stglobal.avi                    The proposed STGLOBAL method


fig1/       results showing the challenges of video stitching.
            It is the stitching of three PointGrey Cricket cameras


fig7/       results showing the comparison of video stitching. Three
            PointGrey Cricket cameras


fig8/       results showing the comparsion of video stitching. Three RED
            cameras


Thank you.

